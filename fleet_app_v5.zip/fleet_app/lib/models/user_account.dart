/// Rol del usuario dentro de la app.
/// - god: el único usuario con permiso total (crear/editar/eliminar
///   vehículos, choferes, y además administrar usuarios comunes).
/// - common: usuario creado por el god, solo puede iniciar sesión y
///   VER la información. No puede crear, editar ni eliminar nada.
enum UserRole { god, common }

extension UserRoleX on UserRole {
  String get value => this == UserRole.god ? 'god' : 'common';

  static UserRole fromValue(String value) =>
      value == 'god' ? UserRole.god : UserRole.common;
}

class UserAccount {
  final String id;
  final String username;
  final String passwordHash;
  final UserRole role;

  UserAccount({
    required this.id,
    required this.username,
    required this.passwordHash,
    required this.role,
  });

  bool get isGod => role == UserRole.god;

  UserAccount copyWith({
    String? username,
    String? passwordHash,
    UserRole? role,
  }) {
    return UserAccount(
      id: id,
      username: username ?? this.username,
      passwordHash: passwordHash ?? this.passwordHash,
      role: role ?? this.role,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'username': username,
      'password_hash': passwordHash,
      'role': role.value,
    };
  }

  factory UserAccount.fromMap(Map<String, dynamic> map) {
    return UserAccount(
      id: map['id'] as String,
      username: map['username'] as String,
      passwordHash: map['password_hash'] as String,
      role: UserRoleX.fromValue(map['role'] as String),
    );
  }
}

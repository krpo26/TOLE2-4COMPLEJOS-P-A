enum LicenseStatus { ok, warning, expired }

class Driver {
  final String id;
  final String fullName;
  final String documentId; // DNI / Identificación
  final String phone;
  final String licenseCategory; // Categoría de licencia / carnet
  final DateTime licenseExpiration; // Vencimiento del carnet
  final DateTime? psychoPhysicalExpiration; // LINTI / psicofísico (opcional)
  final String? photoPath; // Foto del chofer (ruta local en el dispositivo)

  Driver({
    required this.id,
    required this.fullName,
    required this.documentId,
    required this.phone,
    required this.licenseCategory,
    required this.licenseExpiration,
    this.psychoPhysicalExpiration,
    this.photoPath,
  });

  int get daysToLicenseExpiration =>
      licenseExpiration.difference(DateTime.now()).inDays;

  LicenseStatus get licenseStatus {
    final days = daysToLicenseExpiration;
    if (days < 0) return LicenseStatus.expired;
    if (days <= 30) return LicenseStatus.warning;
    return LicenseStatus.ok;
  }

  /// Devuelve true si el vencimiento cae exactamente en uno de los hitos
  /// de aviso (30, 15, 5 días), útil para disparar notificaciones puntuales.
  bool get isAtNotificationMilestone =>
      [30, 15, 5].contains(daysToLicenseExpiration);

  Driver copyWith({
    String? fullName,
    String? documentId,
    String? phone,
    String? licenseCategory,
    DateTime? licenseExpiration,
    DateTime? psychoPhysicalExpiration,
    String? photoPath,
  }) {
    return Driver(
      id: id,
      fullName: fullName ?? this.fullName,
      documentId: documentId ?? this.documentId,
      phone: phone ?? this.phone,
      licenseCategory: licenseCategory ?? this.licenseCategory,
      licenseExpiration: licenseExpiration ?? this.licenseExpiration,
      psychoPhysicalExpiration:
          psychoPhysicalExpiration ?? this.psychoPhysicalExpiration,
      photoPath: photoPath ?? this.photoPath,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'full_name': fullName,
      'document_id': documentId,
      'phone': phone,
      'license_category': licenseCategory,
      'license_expiration': licenseExpiration.toIso8601String(),
      'psycho_physical_expiration':
          psychoPhysicalExpiration?.toIso8601String(),
      'photo_path': photoPath,
    };
  }

  factory Driver.fromMap(Map<String, dynamic> map) {
    return Driver(
      id: map['id'] as String,
      fullName: map['full_name'] as String,
      documentId: map['document_id'] as String,
      phone: map['phone'] as String,
      licenseCategory: map['license_category'] as String,
      licenseExpiration: DateTime.parse(map['license_expiration'] as String),
      psychoPhysicalExpiration: map['psycho_physical_expiration'] != null
          ? DateTime.parse(map['psycho_physical_expiration'] as String)
          : null,
      photoPath: map['photo_path'] as String?,
    );
  }
}

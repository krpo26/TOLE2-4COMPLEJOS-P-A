import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';

import '../firebase_options.dart';
import '../models/driver.dart';
import '../models/maintenance_record.dart';
import '../models/observation_photo.dart';
import '../models/record_photo.dart';
import '../models/vehicle.dart';
import 'database_helper.dart';

/// Sincroniza vehículos, choferes e historial de mantenimiento con
/// Cloud Firestore cuando hay conexión a internet.
///
/// DISEÑO OFFLINE-FIRST: SQLite local es siempre la fuente de verdad
/// para que la app funcione al 100% sin internet. La nube es un
/// respaldo y un medio para compartir datos entre dispositivos del
/// mismo parque automotor — nunca un requisito para operar.
///
/// Los usuarios (login) NO se sincronizan a la nube por seguridad:
/// viven únicamente en SQLite + almacenamiento seguro del dispositivo.
///
/// Si Firebase no fue configurado (ver README), [isCloudEnabled]
/// queda en false y todos los métodos de sync no hacen nada: la app
/// sigue funcionando perfecto en modo offline únicamente.
class SyncService {
  SyncService._internal();
  static final SyncService instance = SyncService._internal();

  bool isCloudEnabled = false;
  DateTime? lastSyncedAt;
  String? lastInitError; // Diagnóstico temporal: motivo si falla la conexión.

  FirebaseFirestore? _firestore;

  Future<void> init() async {
    try {
      try {
        await Firebase.initializeApp(
          options: DefaultFirebaseOptions.currentPlatform,
        );
      } catch (e) {
        // En Android, si google-services.json está presente, el propio
        // sistema ya inicializó la app [DEFAULT] nativamente antes de
        // que Dart llegue a este punto. Eso es normal, no un error real:
        // seguimos usando esa instancia ya inicializada.
        if (!e.toString().contains('duplicate-app')) rethrow;
      }
      _firestore = FirebaseFirestore.instance;
      _firestore!.settings = const Settings(persistenceEnabled: true);
      isCloudEnabled = true;
      lastInitError = null;
    } catch (e) {
      // Sin Firebase configurado o sin poder inicializar: seguimos
      // 100% operativos en modo offline con SQLite.
      isCloudEnabled = false;
      lastInitError = e.toString();
    }
  }

  // ---------------- Push individual (se llama tras cada alta/edición/baja) ----------------

  Future<void> pushVehicle(Vehicle v) async {
    if (!isCloudEnabled) return;
    try {
      await _firestore!.collection('vehicles').doc(v.id).set(v.toMap());
    } catch (_) {
      // Sin conexión: el cambio ya quedó en SQLite; se sincroniza
      // solo cuando vuelva la conexión.
    }
  }

  Future<void> deleteVehicleRemote(String id) async {
    if (!isCloudEnabled) return;
    try {
      await _firestore!.collection('vehicles').doc(id).delete();
    } catch (_) {}
  }

  Future<void> pushDriver(Driver d) async {
    if (!isCloudEnabled) return;
    try {
      await _firestore!.collection('drivers').doc(d.id).set(d.toMap());
    } catch (_) {}
  }

  Future<void> deleteDriverRemote(String id) async {
    if (!isCloudEnabled) return;
    try {
      await _firestore!.collection('drivers').doc(id).delete();
    } catch (_) {}
  }

  Future<void> pushMaintenanceRecord(MaintenanceRecord r) async {
    if (!isCloudEnabled) return;
    try {
      await _firestore!
          .collection('maintenance_records')
          .doc(r.id)
          .set(r.toMap());
    } catch (_) {}
  }

  Future<void> deleteMaintenanceRecordRemote(String id) async {
    if (!isCloudEnabled) return;
    try {
      await _firestore!.collection('maintenance_records').doc(id).delete();
    } catch (_) {}
  }

  Future<void> pushObservationPhoto(ObservationPhoto p) async {
    if (!isCloudEnabled) return;
    try {
      await _firestore!
          .collection('vehicle_observation_photos')
          .doc(p.id)
          .set(p.toMap());
    } catch (_) {}
  }

  Future<void> deleteObservationPhotoRemote(String id) async {
    if (!isCloudEnabled) return;
    try {
      await _firestore!.collection('vehicle_observation_photos').doc(id).delete();
    } catch (_) {}
  }

  Future<void> pushRecordPhoto(RecordPhoto p) async {
    if (!isCloudEnabled) return;
    try {
      await _firestore!
          .collection('maintenance_record_photos')
          .doc(p.id)
          .set(p.toMap());
    } catch (_) {}
  }

  Future<void> deleteRecordPhotoRemote(String id) async {
    if (!isCloudEnabled) return;
    try {
      await _firestore!.collection('maintenance_record_photos').doc(id).delete();
    } catch (_) {}
  }

  // ---------------- Sincronización completa (manual o al reconectar) ----------------

  /// Sube todo lo local a la nube (upsert) y trae todo lo remoto a
  /// SQLite local (upsert). Se usa al reconectar o con "Sincronizar
  /// ahora". No borra nada que no se haya borrado explícitamente.
  Future<void> syncAll() async {
    if (!isCloudEnabled) return;
    try {
      final db = DatabaseHelper.instance;

      final localVehicles = await db.getVehicles();
      final localDrivers = await db.getDrivers();

      for (final v in localVehicles) {
        await _firestore!.collection('vehicles').doc(v.id).set(v.toMap());
      }
      for (final d in localDrivers) {
        await _firestore!.collection('drivers').doc(d.id).set(d.toMap());
      }
      for (final v in localVehicles) {
        final records = await db.getMaintenanceRecords(v.id);
        for (final r in records) {
          await _firestore!
              .collection('maintenance_records')
              .doc(r.id)
              .set(r.toMap());
          final recordPhotos = await db.getRecordPhotos(r.id);
          for (final p in recordPhotos) {
            await _firestore!
                .collection('maintenance_record_photos')
                .doc(p.id)
                .set(p.toMap());
          }
        }
        final obsPhotos = await db.getObservationPhotos(v.id);
        for (final p in obsPhotos) {
          await _firestore!
              .collection('vehicle_observation_photos')
              .doc(p.id)
              .set(p.toMap());
        }
      }

      final remoteVehicles = await _firestore!.collection('vehicles').get();
      for (final doc in remoteVehicles.docs) {
        await db.insertVehicle(Vehicle.fromMap(doc.data()));
      }

      final remoteDrivers = await _firestore!.collection('drivers').get();
      for (final doc in remoteDrivers.docs) {
        await db.insertDriver(Driver.fromMap(doc.data()));
      }

      final remoteRecords =
          await _firestore!.collection('maintenance_records').get();
      for (final doc in remoteRecords.docs) {
        await db.insertMaintenanceRecord(MaintenanceRecord.fromMap(doc.data()));
      }

      final remoteObsPhotos =
          await _firestore!.collection('vehicle_observation_photos').get();
      for (final doc in remoteObsPhotos.docs) {
        await db.insertObservationPhoto(ObservationPhoto.fromMap(doc.data()));
      }

      final remoteRecordPhotos =
          await _firestore!.collection('maintenance_record_photos').get();
      for (final doc in remoteRecordPhotos.docs) {
        await db.insertRecordPhoto(RecordPhoto.fromMap(doc.data()));
      }

      lastSyncedAt = DateTime.now();
    } catch (_) {
      // Falla de red a mitad de sync: no rompe nada, se reintenta
      // en la próxima reconexión o toque de "Sincronizar ahora".
    }
  }
}

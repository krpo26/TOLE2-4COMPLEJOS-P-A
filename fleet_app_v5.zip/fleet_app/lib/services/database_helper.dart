import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

import '../models/driver.dart';
import '../models/maintenance_record.dart';
import '../models/observation_photo.dart';
import '../models/record_photo.dart';
import '../models/user_account.dart';
import '../models/vehicle.dart';

/// Capa de persistencia local. Usa SQLite (sqflite) para que la app
/// funcione 100% offline. El diseño deja preparado el terreno para,
/// en una fase futura, sincronizar estas mismas tablas contra
/// Firebase/Supabase (agregar columnas `updated_at` / `synced` si
/// se desea sincronización incremental).
class DatabaseHelper {
  DatabaseHelper._internal();
  static final DatabaseHelper instance = DatabaseHelper._internal();

  static Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    _db = await _initDb();
    return _db!;
  }

  Future<Database> _initDb() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'fleet_app.db');

    return openDatabase(
      path,
      version: 4,
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
    );
  }

  Future<void> _onUpgrade(Database db, int oldVersion, int newVersion) async {
    if (oldVersion < 2) {
      // Fotos de chofer y documentos de vehículo (cédula verde, título,
      // VTV, seguro), agregadas en una versión posterior de la app.
      for (final col in [
        'photo_path',
        'cedula_verde_path',
        'titulo_path',
        'vtv_path',
        'seguro_path',
      ]) {
        try {
          await db.execute('ALTER TABLE vehicles ADD COLUMN $col TEXT');
        } catch (_) {
          // La columna ya existe (upgrade repetido): se ignora.
        }
      }
      try {
        await db.execute('ALTER TABLE drivers ADD COLUMN photo_path TEXT');
      } catch (_) {}
    }
    if (oldVersion < 3) {
      // Fotos sueltas como "observación" del vehículo, y fotos
      // adjuntas a cada registro del historial de mantenimiento.
      await db.execute('''
        CREATE TABLE IF NOT EXISTS vehicle_observation_photos (
          id TEXT PRIMARY KEY,
          vehicle_id TEXT NOT NULL,
          photo_path TEXT NOT NULL,
          created_at TEXT NOT NULL,
          FOREIGN KEY (vehicle_id) REFERENCES vehicles (id) ON DELETE CASCADE
        )
      ''');
      await db.execute('''
        CREATE TABLE IF NOT EXISTS maintenance_record_photos (
          id TEXT PRIMARY KEY,
          record_id TEXT NOT NULL,
          photo_path TEXT NOT NULL,
          created_at TEXT NOT NULL,
          FOREIGN KEY (record_id) REFERENCES maintenance_records (id) ON DELETE CASCADE
        )
      ''');
    }
    if (oldVersion < 4) {
      // Marca, modelo y tipo de vehículo (camioneta, auto, moto, camión).
      for (final col in ['brand', 'model', 'vehicle_type']) {
        try {
          await db.execute('ALTER TABLE vehicles ADD COLUMN $col TEXT');
        } catch (_) {}
      }
    }
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE vehicles (
        id TEXT PRIMARY KEY,
        plate TEXT UNIQUE NOT NULL,
        internal_number TEXT NOT NULL,
        brand TEXT,
        model TEXT,
        vehicle_type TEXT,
        current_mileage INTEGER NOT NULL,
        last_service_date TEXT,
        next_service_mileage INTEGER NOT NULL,
        notes TEXT,
        photo_path TEXT,
        cedula_verde_path TEXT,
        titulo_path TEXT,
        vtv_path TEXT,
        seguro_path TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE drivers (
        id TEXT PRIMARY KEY,
        full_name TEXT NOT NULL,
        document_id TEXT UNIQUE NOT NULL,
        phone TEXT,
        license_category TEXT,
        license_expiration TEXT NOT NULL,
        psycho_physical_expiration TEXT,
        photo_path TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE users (
        id TEXT PRIMARY KEY,
        username TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        role TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE maintenance_records (
        id TEXT PRIMARY KEY,
        vehicle_id TEXT NOT NULL,
        date TEXT NOT NULL,
        type TEXT NOT NULL,
        description TEXT NOT NULL,
        mileage_at_event INTEGER,
        cost REAL,
        FOREIGN KEY (vehicle_id) REFERENCES vehicles (id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE vehicle_observation_photos (
        id TEXT PRIMARY KEY,
        vehicle_id TEXT NOT NULL,
        photo_path TEXT NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY (vehicle_id) REFERENCES vehicles (id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE maintenance_record_photos (
        id TEXT PRIMARY KEY,
        record_id TEXT NOT NULL,
        photo_path TEXT NOT NULL,
        created_at TEXT NOT NULL,
        FOREIGN KEY (record_id) REFERENCES maintenance_records (id) ON DELETE CASCADE
      )
    ''');
  }

  // ---------------- VEHICLES ----------------

  Future<int> insertVehicle(Vehicle v) async {
    final db = await database;
    return db.insert(
      'vehicles',
      v.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<int> updateVehicle(Vehicle v) async {
    final db = await database;
    return db.update('vehicles', v.toMap(), where: 'id = ?', whereArgs: [v.id]);
  }

  Future<int> deleteVehicle(String id) async {
    final db = await database;
    return db.delete('vehicles', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<Vehicle>> getVehicles() async {
    final db = await database;
    final rows = await db.query('vehicles', orderBy: 'plate ASC');
    return rows.map((r) => Vehicle.fromMap(r)).toList();
  }

  // ---------------- DRIVERS ----------------

  Future<int> insertDriver(Driver d) async {
    final db = await database;
    return db.insert(
      'drivers',
      d.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<int> updateDriver(Driver d) async {
    final db = await database;
    return db.update('drivers', d.toMap(), where: 'id = ?', whereArgs: [d.id]);
  }

  Future<int> deleteDriver(String id) async {
    final db = await database;
    return db.delete('drivers', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<Driver>> getDrivers() async {
    final db = await database;
    final rows = await db.query('drivers', orderBy: 'full_name ASC');
    return rows.map((r) => Driver.fromMap(r)).toList();
  }

  // ---------------- USERS ----------------

  Future<int> insertUser(UserAccount u) async {
    final db = await database;
    return db.insert('users', u.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<int> updateUser(UserAccount u) async {
    final db = await database;
    return db.update('users', u.toMap(), where: 'id = ?', whereArgs: [u.id]);
  }

  Future<int> deleteUser(String id) async {
    final db = await database;
    return db.delete('users', where: 'id = ?', whereArgs: [id]);
  }

  Future<UserAccount?> getUserByUsername(String username) async {
    final db = await database;
    final rows =
        await db.query('users', where: 'username = ?', whereArgs: [username]);
    if (rows.isEmpty) return null;
    return UserAccount.fromMap(rows.first);
  }

  Future<UserAccount?> getUserById(String id) async {
    final db = await database;
    final rows = await db.query('users', where: 'id = ?', whereArgs: [id]);
    if (rows.isEmpty) return null;
    return UserAccount.fromMap(rows.first);
  }

  Future<UserAccount?> getGodUser() async {
    final db = await database;
    final rows =
        await db.query('users', where: 'role = ?', whereArgs: ['god']);
    if (rows.isEmpty) return null;
    return UserAccount.fromMap(rows.first);
  }

  /// Solo los usuarios comunes (excluye al god) para la pantalla de
  /// administración de usuarios.
  Future<List<UserAccount>> getCommonUsers() async {
    final db = await database;
    final rows = await db.query('users',
        where: 'role = ?', whereArgs: ['common'], orderBy: 'username ASC');
    return rows.map((r) => UserAccount.fromMap(r)).toList();
  }

  // ---------------- MAINTENANCE RECORDS ----------------

  Future<int> insertMaintenanceRecord(MaintenanceRecord r) async {
    final db = await database;
    return db.insert('maintenance_records', r.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<int> deleteMaintenanceRecord(String id) async {
    final db = await database;
    return db.delete('maintenance_records', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<MaintenanceRecord>> getMaintenanceRecords(
      String vehicleId) async {
    final db = await database;
    final rows = await db.query('maintenance_records',
        where: 'vehicle_id = ?', whereArgs: [vehicleId], orderBy: 'date DESC');
    return rows.map((r) => MaintenanceRecord.fromMap(r)).toList();
  }

  // ---------------- VEHICLE OBSERVATION PHOTOS ----------------
  // Fotos sueltas adjuntas al campo "Observaciones" de un vehículo.

  Future<int> insertObservationPhoto(ObservationPhoto p) async {
    final db = await database;
    return db.insert('vehicle_observation_photos', p.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<int> deleteObservationPhoto(String id) async {
    final db = await database;
    return db.delete('vehicle_observation_photos',
        where: 'id = ?', whereArgs: [id]);
  }

  Future<List<ObservationPhoto>> getObservationPhotos(
      String vehicleId) async {
    final db = await database;
    final rows = await db.query('vehicle_observation_photos',
        where: 'vehicle_id = ?',
        whereArgs: [vehicleId],
        orderBy: 'created_at DESC');
    return rows.map((r) => ObservationPhoto.fromMap(r)).toList();
  }

  // ---------------- MAINTENANCE RECORD PHOTOS ----------------
  // Fotos adjuntas a un registro puntual del historial (arreglo/avería).

  Future<int> insertRecordPhoto(RecordPhoto p) async {
    final db = await database;
    return db.insert('maintenance_record_photos', p.toMap(),
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<int> deleteRecordPhoto(String id) async {
    final db = await database;
    return db.delete('maintenance_record_photos',
        where: 'id = ?', whereArgs: [id]);
  }

  Future<List<RecordPhoto>> getRecordPhotos(String recordId) async {
    final db = await database;
    final rows = await db.query('maintenance_record_photos',
        where: 'record_id = ?',
        whereArgs: [recordId],
        orderBy: 'created_at DESC');
    return rows.map((r) => RecordPhoto.fromMap(r)).toList();
  }
}

import 'package:flutter_local_notifications/flutter_local_notifications.dart';

import '../models/driver.dart';
import '../models/vehicle.dart';

/// Encapsula las notificaciones push locales del sistema operativo
/// (Android/iOS) para alertas de service y vencimiento de carnet.
class NotificationService {
  NotificationService._internal();
  static final NotificationService instance = NotificationService._internal();

  final _plugin = FlutterLocalNotificationsPlugin();

  Future<void> init() async {
    const androidInit = AndroidInitializationSettings('@mipmap/ic_launcher');
    const iosInit = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );
    const settings =
        InitializationSettings(android: androidInit, iOS: iosInit);
    await _plugin.initialize(settings);
  }

  Future<void> _show(int id, String title, String body) async {
    const androidDetails = AndroidNotificationDetails(
      'fleet_alerts',
      'Alertas de flota',
      channelDescription: 'Alertas de service y vencimientos de carnet',
      importance: Importance.high,
      priority: Priority.high,
    );
    const iosDetails = DarwinNotificationDetails();
    const details =
        NotificationDetails(android: androidDetails, iOS: iosDetails);
    await _plugin.show(id, title, body, details);
  }

  Future<void> notifyVehicleMaintenance(Vehicle v) async {
    if (v.maintenanceStatus == MaintenanceStatus.ok) return;
    final title = v.maintenanceStatus == MaintenanceStatus.overdue
        ? 'Service vencido'
        : 'Service próximo';
    final body = v.maintenanceStatus == MaintenanceStatus.overdue
        ? 'La unidad ${v.internalNumber} (${v.plate}) superó el kilometraje de service.'
        : 'La unidad ${v.internalNumber} (${v.plate}) está a ${v.kmRemaining} km del próximo service.';
    await _show(v.plate.hashCode, title, body);
  }

  Future<void> notifyDriverLicense(Driver d) async {
    if (d.licenseStatus == LicenseStatus.ok) return;
    final days = d.daysToLicenseExpiration;
    final title = d.licenseStatus == LicenseStatus.expired
        ? 'Carnet vencido'
        : 'Carnet por vencer';
    final body = d.licenseStatus == LicenseStatus.expired
        ? '${d.fullName} tiene el carnet de conducir vencido.'
        : '${d.fullName} tiene el carnet vence en $days días.';
    await _show(d.documentId.hashCode, title, body);
  }

  /// Recorre listas completas y dispara notificaciones para todos los
  /// casos en warning/overdue. Pensado para llamarse al abrir la app
  /// o desde una tarea programada en background.
  Future<void> checkAndNotifyAll(
      List<Vehicle> vehicles, List<Driver> drivers) async {
    for (final v in vehicles) {
      await notifyVehicleMaintenance(v);
    }
    for (final d in drivers) {
      await notifyDriverLicense(d);
    }
  }
}

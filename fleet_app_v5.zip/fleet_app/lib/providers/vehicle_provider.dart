import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';

import '../models/vehicle.dart';
import '../services/database_helper.dart';
import '../services/notification_service.dart';
import '../services/sync_service.dart';

class VehicleProvider extends ChangeNotifier {
  final List<Vehicle> _vehicles = [];
  bool isLoading = false;

  List<Vehicle> get vehicles => List.unmodifiable(_vehicles);

  List<Vehicle> get criticalVehicles => _vehicles
      .where((v) => v.maintenanceStatus != MaintenanceStatus.ok)
      .toList();

  Future<void> load() async {
    isLoading = true;
    notifyListeners();
    final data = await DatabaseHelper.instance.getVehicles();
    _vehicles
      ..clear()
      ..addAll(data);
    isLoading = false;
    notifyListeners();
  }

  Future<void> addVehicle({
    required String plate,
    required String internalNumber,
    String brand = '',
    String model = '',
    String vehicleType = '',
    required int currentMileage,
    required int nextServiceMileage,
    DateTime? lastServiceDate,
    String notes = '',
    String? photoPath,
    String? cedulaVerdePath,
    String? tituloPath,
    String? vtvPath,
    String? seguroPath,
  }) async {
    final vehicle = Vehicle(
      id: const Uuid().v4(),
      plate: plate,
      internalNumber: internalNumber,
      brand: brand,
      model: model,
      vehicleType: vehicleType,
      currentMileage: currentMileage,
      nextServiceMileage: nextServiceMileage,
      lastServiceDate: lastServiceDate,
      notes: notes,
      photoPath: photoPath,
      cedulaVerdePath: cedulaVerdePath,
      tituloPath: tituloPath,
      vtvPath: vtvPath,
      seguroPath: seguroPath,
    );
    await DatabaseHelper.instance.insertVehicle(vehicle);
    await load();
    await NotificationService.instance.notifyVehicleMaintenance(vehicle);
    unawaited(SyncService.instance.pushVehicle(vehicle));
  }

  Future<void> updateVehicle(Vehicle vehicle) async {
    await DatabaseHelper.instance.updateVehicle(vehicle);
    await load();
    await NotificationService.instance.notifyVehicleMaintenance(vehicle);
    unawaited(SyncService.instance.pushVehicle(vehicle));
  }

  Future<void> deleteVehicle(String id) async {
    await DatabaseHelper.instance.deleteVehicle(id);
    await load();
    unawaited(SyncService.instance.deleteVehicleRemote(id));
  }
}

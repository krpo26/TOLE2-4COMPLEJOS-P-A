import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';

import '../models/driver.dart';
import '../services/database_helper.dart';
import '../services/notification_service.dart';
import '../services/sync_service.dart';

class DriverProvider extends ChangeNotifier {
  final List<Driver> _drivers = [];
  bool isLoading = false;

  List<Driver> get drivers => List.unmodifiable(_drivers);

  List<Driver> get criticalDrivers => _drivers
      .where((d) => d.licenseStatus != LicenseStatus.ok)
      .toList();

  Future<void> load() async {
    isLoading = true;
    notifyListeners();
    final data = await DatabaseHelper.instance.getDrivers();
    _drivers
      ..clear()
      ..addAll(data);
    isLoading = false;
    notifyListeners();
  }

  Future<void> addDriver({
    required String fullName,
    required String documentId,
    required String phone,
    required String licenseCategory,
    required DateTime licenseExpiration,
    DateTime? psychoPhysicalExpiration,
    String? photoPath,
  }) async {
    final driver = Driver(
      id: const Uuid().v4(),
      fullName: fullName,
      documentId: documentId,
      phone: phone,
      licenseCategory: licenseCategory,
      licenseExpiration: licenseExpiration,
      psychoPhysicalExpiration: psychoPhysicalExpiration,
      photoPath: photoPath,
    );
    await DatabaseHelper.instance.insertDriver(driver);
    await load();
    await NotificationService.instance.notifyDriverLicense(driver);
    unawaited(SyncService.instance.pushDriver(driver));
  }

  Future<void> updateDriver(Driver driver) async {
    await DatabaseHelper.instance.updateDriver(driver);
    await load();
    await NotificationService.instance.notifyDriverLicense(driver);
    unawaited(SyncService.instance.pushDriver(driver));
  }

  Future<void> deleteDriver(String id) async {
    await DatabaseHelper.instance.deleteDriver(id);
    await load();
    unawaited(SyncService.instance.deleteDriverRemote(id));
  }
}

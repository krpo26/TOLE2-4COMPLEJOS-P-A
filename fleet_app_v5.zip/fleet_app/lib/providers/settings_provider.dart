import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Colores institucionales disponibles para elegir como acento de la app.
class AppColorOption {
  final String name;
  final Color color;
  const AppColorOption(this.name, this.color);
}

const List<AppColorOption> kColorOptions = [
  AppColorOption('Azul institucional', Color(0xFF0D47A1)),
  AppColorOption('Gris acero', Color(0xFF37474F)),
  AppColorOption('Verde', Color(0xFF2E7D32)),
  AppColorOption('Bordó', Color(0xFF8E1B2E)),
  AppColorOption('Dorado', Color(0xFFB8860B)),
];

/// Fuentes disponibles para el texto de toda la app.
enum AppFont { system, roboto, poppins, montserrat }

extension AppFontX on AppFont {
  String get label {
    switch (this) {
      case AppFont.system:
        return 'Predeterminada';
      case AppFont.roboto:
        return 'Roboto';
      case AppFont.poppins:
        return 'Poppins';
      case AppFont.montserrat:
        return 'Montserrat';
    }
  }
}

/// Maneja las preferencias visuales del usuario: modo claro/oscuro,
/// color de acento y tipografía. Se guardan en el dispositivo (no se
/// sincronizan a la nube) y se aplican a toda la app vía [FleetApp].
class SettingsProvider extends ChangeNotifier {
  static const _kThemeModeKey = 'settings_theme_mode';
  static const _kColorIndexKey = 'settings_color_index';
  static const _kFontKey = 'settings_font';

  ThemeMode themeMode = ThemeMode.system;
  int colorIndex = 0;
  AppFont font = AppFont.system;

  Color get seedColor => kColorOptions[colorIndex].color;

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final modeIndex = prefs.getInt(_kThemeModeKey);
    if (modeIndex != null && modeIndex < ThemeMode.values.length) {
      themeMode = ThemeMode.values[modeIndex];
    }
    colorIndex = prefs.getInt(_kColorIndexKey) ?? 0;
    if (colorIndex >= kColorOptions.length) colorIndex = 0;
    final fontIndex = prefs.getInt(_kFontKey);
    if (fontIndex != null && fontIndex < AppFont.values.length) {
      font = AppFont.values[fontIndex];
    }
    notifyListeners();
  }

  Future<void> setThemeMode(ThemeMode mode) async {
    themeMode = mode;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_kThemeModeKey, mode.index);
  }

  Future<void> setColorIndex(int index) async {
    colorIndex = index;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_kColorIndexKey, index);
  }

  Future<void> setFont(AppFont value) async {
    font = value;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_kFontKey, value.index);
  }
}

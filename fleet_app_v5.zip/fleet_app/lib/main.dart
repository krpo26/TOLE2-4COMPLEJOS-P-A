import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

import 'providers/auth_provider.dart';
import 'providers/driver_provider.dart';
import 'providers/settings_provider.dart';
import 'providers/sync_provider.dart';
import 'providers/vehicle_provider.dart';
import 'screens/auth_gate.dart';
import 'services/notification_service.dart';
import 'services/sync_service.dart';

/// Nombre institucional del sistema: PARQUE AUTOMOTOR BENJAMIN PAZ
const String kAppTitle = 'PARQUE AUTOMOTOR BENJAMIN PAZ';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await NotificationService.instance.init();
  // Si Firebase no está configurado (ver README), esto falla en
  // silencio y la app sigue funcionando 100% offline con SQLite.
  await SyncService.instance.init();
  runApp(const FleetApp());
}

class FleetApp extends StatelessWidget {
  const FleetApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => VehicleProvider()..load()),
        ChangeNotifierProvider(create: (_) => DriverProvider()..load()),
        ChangeNotifierProvider(create: (_) => AuthProvider()),
        ChangeNotifierProvider(create: (_) => SyncProvider()),
        ChangeNotifierProvider(create: (_) => SettingsProvider()..load()),
      ],
      child: Consumer<SettingsProvider>(
        builder: (context, settings, _) {
          TextTheme? textTheme;
          switch (settings.font) {
            case AppFont.roboto:
              textTheme = GoogleFonts.robotoTextTheme();
              break;
            case AppFont.poppins:
              textTheme = GoogleFonts.poppinsTextTheme();
              break;
            case AppFont.montserrat:
              textTheme = GoogleFonts.montserratTextTheme();
              break;
            case AppFont.system:
              textTheme = null;
              break;
          }

          ThemeData buildTheme(Brightness brightness) {
            var theme = ThemeData(
              colorSchemeSeed: settings.seedColor,
              brightness: brightness,
              useMaterial3: true,
              appBarTheme:
                  const AppBarTheme(centerTitle: true, elevation: 0),
              filledButtonTheme: FilledButtonThemeData(
                style: FilledButton.styleFrom(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                ),
              ),
            );
            if (textTheme != null) {
              theme = theme.copyWith(
                textTheme: textTheme.apply(
                  bodyColor: theme.colorScheme.onSurface,
                  displayColor: theme.colorScheme.onSurface,
                ),
              );
            }
            return theme;
          }

          return MaterialApp(
            title: kAppTitle,
            debugShowCheckedModeBanner: false,
            themeMode: settings.themeMode,
            theme: buildTheme(Brightness.light),
            darkTheme: buildTheme(Brightness.dark),
            home: const AppStartup(),
          );
        },
      ),
    );
  }
}

/// Arranca la sincronización online/offline una vez que los
/// providers ya existen en el árbol, y solo entonces muestra el
/// flujo normal de autenticación.
class AppStartup extends StatefulWidget {
  const AppStartup({super.key});

  @override
  State<AppStartup> createState() => _AppStartupState();
}

class _AppStartupState extends State<AppStartup> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      context.read<SyncProvider>().start(onSynced: () {
        if (!mounted) return;
        context.read<VehicleProvider>().load();
        context.read<DriverProvider>().load();
      });
    });
  }

  @override
  Widget build(BuildContext context) => const AuthGate();
}

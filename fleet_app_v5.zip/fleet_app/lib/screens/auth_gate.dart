import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../providers/auth_provider.dart';
import '../services/auth_service.dart';
import 'auth/login_screen.dart';
import 'auth/setup_screen.dart';
import 'dashboard_screen.dart';

/// Punto de entrada de navegación: decide qué pantalla mostrar según
/// el estado de autenticación (setup inicial / login / dashboard).
class AuthGate extends StatelessWidget {
  const AuthGate({super.key});

  Future<_AuthState> _resolveState(BuildContext context) async {
    final needsSetup = await AuthService.instance.needsSetup();
    if (needsSetup) return _AuthState.setup;

    await context.read<AuthProvider>().refresh();
    final loggedIn = context.read<AuthProvider>().isLoggedIn;
    return loggedIn ? _AuthState.dashboard : _AuthState.login;
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<_AuthState>(
      future: _resolveState(context),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }
        switch (snapshot.data!) {
          case _AuthState.setup:
            return const SetupScreen();
          case _AuthState.login:
            return const LoginScreen();
          case _AuthState.dashboard:
            return const DashboardScreen();
        }
      },
    );
  }
}

enum _AuthState { setup, login, dashboard }

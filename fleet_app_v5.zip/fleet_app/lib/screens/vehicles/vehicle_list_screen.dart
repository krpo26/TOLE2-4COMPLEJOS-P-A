import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/vehicle.dart';
import '../../providers/auth_provider.dart';
import '../../providers/vehicle_provider.dart';
import '../../widgets/status_badge.dart';
import 'vehicle_form_screen.dart';

class VehicleListScreen extends StatelessWidget {
  const VehicleListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<VehicleProvider>();
    final isGod = context.watch<AuthProvider>().isGod;
    final vehicles = provider.vehicles;

    return Scaffold(
      appBar: AppBar(title: const Text('Vehículos')),
      body: provider.isLoading
          ? const Center(child: CircularProgressIndicator())
          : vehicles.isEmpty
              ? const Center(child: Text('No hay vehículos cargados.'))
              : ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: vehicles.length,
                  itemBuilder: (context, index) {
                    final v = vehicles[index];
                    return _VehicleTile(vehicle: v, readOnly: !isGod);
                  },
                ),
      floatingActionButton: isGod
          ? FloatingActionButton.extended(
              icon: const Icon(Icons.add),
              label: const Text('Nuevo'),
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const VehicleFormScreen()),
              ),
            )
          : null,
    );
  }
}

class _VehicleTile extends StatelessWidget {
  final Vehicle vehicle;
  final bool readOnly;
  const _VehicleTile({required this.vehicle, required this.readOnly});

  Color _statusColor() {
    switch (vehicle.maintenanceStatus) {
      case MaintenanceStatus.ok:
        return Colors.green;
      case MaintenanceStatus.warning:
        return Colors.amber.shade800;
      case MaintenanceStatus.overdue:
        return Colors.red;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: CircleAvatar(
          backgroundColor: _statusColor().withOpacity(0.15),
          child: Icon(Icons.local_shipping, color: _statusColor()),
        ),
        title: Text('${vehicle.internalNumber} · ${vehicle.plate}',
            style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text([
          if (vehicle.brand.isNotEmpty || vehicle.model.isNotEmpty)
            '${vehicle.brand} ${vehicle.model}'.trim(),
          if (vehicle.vehicleType.isNotEmpty) vehicle.vehicleType,
          '${vehicle.currentMileage} km actuales',
          'Próx. service: ${vehicle.nextServiceMileage} km',
        ].join(' · ')),
        trailing: StatusBadge.forMaintenance(vehicle.maintenanceStatus),
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(
              builder: (_) =>
                  VehicleFormScreen(vehicle: vehicle, readOnly: readOnly)),
        ),
      ),
    );
  }
}

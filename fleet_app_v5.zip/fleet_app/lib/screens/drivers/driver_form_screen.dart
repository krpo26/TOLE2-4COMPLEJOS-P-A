import 'dart:io';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import '../../models/driver.dart';
import '../../providers/driver_provider.dart';
import '../../services/image_picker_service.dart';

class DriverFormScreen extends StatefulWidget {
  final Driver? driver;
  final bool readOnly;

  const DriverFormScreen({super.key, this.driver, this.readOnly = false});

  @override
  State<DriverFormScreen> createState() => _DriverFormScreenState();
}

class _DriverFormScreenState extends State<DriverFormScreen> {
  final _formKey = GlobalKey<FormState>();

  late final TextEditingController _nameCtrl;
  late final TextEditingController _dniCtrl;
  late final TextEditingController _phoneCtrl;
  late final TextEditingController _categoryCtrl;
  DateTime? _licenseExpiration;
  DateTime? _psychoPhysicalExpiration;
  String? _photoPath;

  bool get _isEditing => widget.driver != null;

  @override
  void initState() {
    super.initState();
    final d = widget.driver;
    _nameCtrl = TextEditingController(text: d?.fullName ?? '');
    _dniCtrl = TextEditingController(text: d?.documentId ?? '');
    _phoneCtrl = TextEditingController(text: d?.phone ?? '');
    _categoryCtrl = TextEditingController(text: d?.licenseCategory ?? '');
    _licenseExpiration = d?.licenseExpiration;
    _psychoPhysicalExpiration = d?.psychoPhysicalExpiration;
    _photoPath = d?.photoPath;
  }

  Future<void> _pickPhoto() async {
    final source = await showModalBottomSheet<bool>(
      context: context,
      builder: (context) => SafeArea(
        child: Wrap(
          children: [
            ListTile(
              leading: const Icon(Icons.photo_camera_outlined),
              title: const Text('Tomar foto'),
              onTap: () => Navigator.pop(context, true),
            ),
            ListTile(
              leading: const Icon(Icons.photo_library_outlined),
              title: const Text('Elegir de la galería'),
              onTap: () => Navigator.pop(context, false),
            ),
          ],
        ),
      ),
    );
    if (source == null) return;
    final path = await ImagePickerService.pickAndSave(fromCamera: source);
    if (path != null) setState(() => _photoPath = path);
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _dniCtrl.dispose();
    _phoneCtrl.dispose();
    _categoryCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickDate({required bool isLicense}) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );
    if (picked == null) return;
    setState(() {
      if (isLicense) {
        _licenseExpiration = picked;
      } else {
        _psychoPhysicalExpiration = picked;
      }
    });
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    if (_licenseExpiration == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Seleccioná la fecha de vencimiento del carnet')));
      return;
    }

    final provider = context.read<DriverProvider>();

    if (_isEditing) {
      final updated = widget.driver!.copyWith(
        fullName: _nameCtrl.text.trim(),
        documentId: _dniCtrl.text.trim(),
        phone: _phoneCtrl.text.trim(),
        licenseCategory: _categoryCtrl.text.trim(),
        licenseExpiration: _licenseExpiration,
        psychoPhysicalExpiration: _psychoPhysicalExpiration,
        photoPath: _photoPath,
      );
      await provider.updateDriver(updated);
    } else {
      await provider.addDriver(
        fullName: _nameCtrl.text.trim(),
        documentId: _dniCtrl.text.trim(),
        phone: _phoneCtrl.text.trim(),
        licenseCategory: _categoryCtrl.text.trim(),
        licenseExpiration: _licenseExpiration!,
        psychoPhysicalExpiration: _psychoPhysicalExpiration,
        photoPath: _photoPath,
      );
    }

    if (mounted) Navigator.pop(context);
  }

  Future<void> _delete() async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Eliminar chofer'),
        content: const Text('¿Seguro que querés eliminar este chofer?'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('Cancelar')),
          TextButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('Eliminar')),
        ],
      ),
    );
    if (confirmed == true && mounted) {
      await context.read<DriverProvider>().deleteDriver(widget.driver!.id);
      if (mounted) Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.readOnly
            ? 'Detalle del chofer'
            : (_isEditing ? 'Editar chofer' : 'Nuevo chofer')),
        actions: [
          if (_isEditing && !widget.readOnly)
            IconButton(
                onPressed: _delete, icon: const Icon(Icons.delete_outline)),
        ],
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Center(
              child: GestureDetector(
                onTap: widget.readOnly ? null : _pickPhoto,
                child: Stack(
                  children: [
                    CircleAvatar(
                      radius: 52,
                      backgroundColor: Colors.grey.shade200,
                      backgroundImage: (_photoPath != null &&
                              File(_photoPath!).existsSync())
                          ? FileImage(File(_photoPath!))
                          : null,
                      child: (_photoPath == null ||
                              !File(_photoPath!).existsSync())
                          ? Icon(Icons.person,
                              size: 52, color: Colors.grey.shade500)
                          : null,
                    ),
                    if (!widget.readOnly)
                      Positioned(
                        bottom: 0,
                        right: 0,
                        child: CircleAvatar(
                          radius: 16,
                          backgroundColor:
                              Theme.of(context).colorScheme.primary,
                          child: const Icon(Icons.camera_alt,
                              size: 16, color: Colors.white),
                        ),
                      ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),
            TextFormField(
              controller: _nameCtrl,
              enabled: !widget.readOnly,
              decoration: const InputDecoration(
                  labelText: 'Nombre y apellido', border: OutlineInputBorder()),
              validator: (v) =>
                  (v == null || v.trim().isEmpty) ? 'Campo obligatorio' : null,
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _dniCtrl,
              enabled: !widget.readOnly,
              decoration: const InputDecoration(
                  labelText: 'DNI / Identificación',
                  border: OutlineInputBorder()),
              keyboardType: TextInputType.number,
              validator: (v) =>
                  (v == null || v.trim().isEmpty) ? 'Campo obligatorio' : null,
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _phoneCtrl,
              enabled: !widget.readOnly,
              decoration: const InputDecoration(
                  labelText: 'Teléfono de contacto',
                  border: OutlineInputBorder()),
              keyboardType: TextInputType.phone,
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _categoryCtrl,
              enabled: !widget.readOnly,
              decoration: const InputDecoration(
                  labelText: 'Categoría de licencia / carnet',
                  border: OutlineInputBorder()),
              validator: (v) =>
                  (v == null || v.trim().isEmpty) ? 'Campo obligatorio' : null,
            ),
            const SizedBox(height: 16),
            InkWell(
              onTap: widget.readOnly ? null : () => _pickDate(isLicense: true),
              child: InputDecorator(
                decoration: const InputDecoration(
                    labelText: 'Vencimiento del carnet de conducir',
                    border: OutlineInputBorder()),
                child: Text(_licenseExpiration == null
                    ? 'Seleccionar fecha'
                    : DateFormat('dd/MM/yyyy').format(_licenseExpiration!)),
              ),
            ),
            const SizedBox(height: 16),
            InkWell(
              onTap:
                  widget.readOnly ? null : () => _pickDate(isLicense: false),
              child: InputDecorator(
                decoration: const InputDecoration(
                    labelText: 'Vencimiento LINTI / psicofísico (opcional)',
                    border: OutlineInputBorder()),
                child: Text(_psychoPhysicalExpiration == null
                    ? 'Seleccionar fecha'
                    : DateFormat('dd/MM/yyyy')
                        .format(_psychoPhysicalExpiration!)),
              ),
            ),
            const SizedBox(height: 24),
            if (!widget.readOnly)
              FilledButton.icon(
                onPressed: _save,
                icon: const Icon(Icons.save),
                label: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  child: Text(_isEditing ? 'Guardar cambios' : 'Guardar chofer'),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

import 'dart:io';

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../models/driver.dart';
import '../../providers/auth_provider.dart';
import '../../providers/driver_provider.dart';
import '../../widgets/status_badge.dart';
import 'driver_form_screen.dart';

class DriverListScreen extends StatelessWidget {
  const DriverListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<DriverProvider>();
    final isGod = context.watch<AuthProvider>().isGod;
    final drivers = provider.drivers;

    return Scaffold(
      appBar: AppBar(title: const Text('Choferes')),
      body: provider.isLoading
          ? const Center(child: CircularProgressIndicator())
          : drivers.isEmpty
              ? const Center(child: Text('No hay choferes cargados.'))
              : ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: drivers.length,
                  itemBuilder: (context, index) {
                    final d = drivers[index];
                    return _DriverTile(driver: d, readOnly: !isGod);
                  },
                ),
      floatingActionButton: isGod
          ? FloatingActionButton.extended(
              icon: const Icon(Icons.add),
              label: const Text('Nuevo'),
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const DriverFormScreen()),
              ),
            )
          : null,
    );
  }
}

class _DriverTile extends StatelessWidget {
  final Driver driver;
  final bool readOnly;
  const _DriverTile({required this.driver, required this.readOnly});

  Color _statusColor() {
    switch (driver.licenseStatus) {
      case LicenseStatus.ok:
        return Colors.green;
      case LicenseStatus.warning:
        return Colors.amber.shade800;
      case LicenseStatus.expired:
        return Colors.red;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        leading: CircleAvatar(
          backgroundColor: _statusColor().withOpacity(0.15),
          backgroundImage: (driver.photoPath != null &&
                  File(driver.photoPath!).existsSync())
              ? FileImage(File(driver.photoPath!))
              : null,
          child: (driver.photoPath == null ||
                  !File(driver.photoPath!).existsSync())
              ? Icon(Icons.person, color: _statusColor())
              : null,
        ),
        title: Text(driver.fullName,
            style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(
            'DNI ${driver.documentId} · Cat. ${driver.licenseCategory}'),
        trailing: StatusBadge.forLicense(driver.licenseStatus),
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(
              builder: (_) =>
                  DriverFormScreen(driver: driver, readOnly: readOnly)),
        ),
      ),
    );
  }
}

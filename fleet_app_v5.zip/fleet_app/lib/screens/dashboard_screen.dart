import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../models/driver.dart';
import '../models/vehicle.dart';
import '../providers/auth_provider.dart';
import '../providers/driver_provider.dart';
import '../providers/sync_provider.dart';
import '../providers/vehicle_provider.dart';
import '../services/pdf_report_service.dart';
import '../services/sync_service.dart';
import '../widgets/stat_card.dart';
import '../widgets/status_badge.dart';
import 'auth/login_screen.dart';
import 'drivers/driver_list_screen.dart';
import 'settings_screen.dart';
import 'users/user_management_screen.dart';
import 'vehicles/vehicle_list_screen.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final vehicleProvider = context.watch<VehicleProvider>();
    final driverProvider = context.watch<DriverProvider>();
    final authProvider = context.watch<AuthProvider>();
    final syncProvider = context.watch<SyncProvider>();
    final isGod = authProvider.isGod;

    final criticalVehicles = vehicleProvider.criticalVehicles;
    final criticalDrivers = driverProvider.criticalDrivers;
    final totalCritical = criticalVehicles.length + criticalDrivers.length;

    return Scaffold(
      appBar: AppBar(
        title: const Text('PARQUE AUTOMOTOR\nBENJAMIN PAZ',
            textAlign: TextAlign.center, style: TextStyle(fontSize: 16)),
        actions: [
          IconButton(
            tooltip: 'Apariencia',
            icon: const Icon(Icons.palette_outlined),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const SettingsScreen()),
            ),
          ),
          if (syncProvider.isCloudEnabled)
            IconButton(
              tooltip: 'Sincronizar ahora',
              icon: syncProvider.isSyncing
                  ? const SizedBox(
                      height: 20,
                      width: 20,
                      child: CircularProgressIndicator(
                          strokeWidth: 2, color: Colors.white),
                    )
                  : const Icon(Icons.sync),
              onPressed:
                  syncProvider.isSyncing ? null : () => syncProvider.syncNow(),
            ),
          IconButton(
            tooltip: 'Exportar reporte PDF',
            icon: const Icon(Icons.picture_as_pdf_outlined),
            onPressed: () => PdfReportService.generateAndShare(
              vehicles: vehicleProvider.vehicles,
              drivers: driverProvider.drivers,
            ),
          ),
          if (isGod)
            IconButton(
              tooltip: 'Administrar usuarios',
              icon: const Icon(Icons.manage_accounts_outlined),
              onPressed: () => Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => const UserManagementScreen()),
              ),
            ),
          IconButton(
            tooltip: 'Cerrar sesión',
            icon: const Icon(Icons.logout),
            onPressed: () async {
              await context.read<AuthProvider>().logout();
              if (context.mounted) {
                Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (_) => const LoginScreen()),
                  (route) => false,
                );
              }
            },
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          await vehicleProvider.load();
          await driverProvider.load();
        },
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _SyncStatusBanner(syncProvider: syncProvider),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: StatCard(
                    title: 'Vehículos',
                    value: '${vehicleProvider.vehicles.length}',
                    icon: Icons.local_shipping,
                    color: Colors.blue,
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => const VehicleListScreen())),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: StatCard(
                    title: 'Choferes',
                    value: '${driverProvider.drivers.length}',
                    icon: Icons.person,
                    color: Colors.indigo,
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => const DriverListScreen())),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            StatCard(
              title: 'Alertas críticas',
              value: '$totalCritical',
              icon: Icons.warning_amber_rounded,
              color: totalCritical > 0 ? Colors.red : Colors.green,
            ),
            const SizedBox(height: 24),
            const Text('Alertas críticas',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            if (totalCritical == 0)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 24),
                child: Center(
                  child: Text('Sin alertas. Todo en orden ✅',
                      style: TextStyle(color: Colors.grey)),
                ),
              )
            else ...[
              ...criticalVehicles.map((v) => _VehicleAlertTile(vehicle: v)),
              ...criticalDrivers.map((d) => _DriverAlertTile(driver: d)),
            ],
          ],
        ),
      ),
    );
  }
}

class _VehicleAlertTile extends StatelessWidget {
  final Vehicle vehicle;
  const _VehicleAlertTile({required this.vehicle});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: const Icon(Icons.build_circle_outlined),
        title: Text('${vehicle.internalNumber} · ${vehicle.plate}'),
        subtitle: Text(vehicle.kmRemaining <= 0
            ? 'Service superado por ${-vehicle.kmRemaining} km'
            : 'Faltan ${vehicle.kmRemaining} km para el service'),
        trailing: StatusBadge.forMaintenance(vehicle.maintenanceStatus),
      ),
    );
  }
}

class _DriverAlertTile extends StatelessWidget {
  final Driver driver;
  const _DriverAlertTile({required this.driver});

  @override
  Widget build(BuildContext context) {
    final days = driver.daysToLicenseExpiration;
    return Card(
      child: ListTile(
        leading: const Icon(Icons.badge_outlined),
        title: Text(driver.fullName),
        subtitle: Text(days < 0
            ? 'Carnet vencido hace ${-days} días'
            : 'Carnet vence en $days días'),
        trailing: StatusBadge.forLicense(driver.licenseStatus),
      ),
    );
  }
}

/// Chip informativo: muestra si la app está online/offline y, si la
/// nube está configurada, cuándo fue la última sincronización. La
/// app funciona igual de bien en cualquiera de los dos estados.
class _SyncStatusBanner extends StatelessWidget {
  final SyncProvider syncProvider;
  const _SyncStatusBanner({required this.syncProvider});

  @override
  Widget build(BuildContext context) {
    if (!syncProvider.isCloudEnabled) {
      final error = SyncService.instance.lastInitError;
      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          color: Colors.grey.withOpacity(0.12),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Row(
              children: [
                Icon(Icons.storage, size: 18, color: Colors.grey),
                SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Modo offline (base local). La sincronización en la nube no está configurada.',
                    style: TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                ),
              ],
            ),
            if (error != null) ...[
              const SizedBox(height: 4),
              SelectableText(
                'Diagnóstico: $error',
                style: const TextStyle(fontSize: 10, color: Colors.redAccent),
              ),
            ],
          ],
        ),
      );
    }

    final online = syncProvider.isOnline;
    final color = online ? Colors.green : Colors.orange;
    final lastSync = syncProvider.lastSyncedAt;
    final syncText = syncProvider.isSyncing
        ? 'Sincronizando...'
        : (lastSync != null
            ? 'Última sincronización: ${TimeOfDay.fromDateTime(lastSync).format(context)}'
            : 'Sin sincronizar todavía');

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: color.withOpacity(0.12),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        children: [
          Icon(online ? Icons.cloud_done_outlined : Icons.cloud_off_outlined,
              size: 18, color: color),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              '${online ? 'En línea' : 'Sin conexión (modo offline)'} · $syncText',
              style: TextStyle(fontSize: 12, color: color),
            ),
          ),
        ],
      ),
    );
  }
}
